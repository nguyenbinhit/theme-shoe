<?php
    /**
     * Plugin Name:       Test Plugin
     * Plugin URI:        https://example.com/
     * Description:       Mo ta
     * Version:           1.0.0
     * Requires at least: 5.2
     * Requires PHP:      7.2
     * Author:            binh
     * Author URI:        https://author.example.com/
     * License:           GPL v2 or later
     * License URI:       https://www.gnu.org/licenses/gpl-2.0.html
     * Text Domain:       test-plugin
     * Domain Path:       /languages
     */

    add_action( 'admin_menu', 'misha_menu_page' );
 
    function misha_menu_page() {
        add_menu_page(
            'My Page Title', // page <title>Title</title>
            'Test Title', // menu link text
            'manage_options', // capability to access the page
            'misha-slug', // page URL slug
            'misha_page_content', // callback function /w content
            'dashicons-star-half', // menu icon
            5 // priority
        );
    
    }
    
    function misha_page_content(){
    
?>
    <div class="wrap">
        <h1>Title Settings</h1>
        <form method="post" action="options.php">
            <?php 
                settings_fields( 'misha_settings' ); // settings group name
                do_settings_sections( 'misha-slug' ); // just a page slug
                submit_button();
            ?>
        </form>
    </div>
<?php
    }

    add_action( 'admin_init',  'misha_register_setting' );
 
    function misha_register_setting(){
    
        register_setting(
            'misha_settings', // settings group name
            'homepage_text', // option name
            'sanitize_text_field' // sanitization function
        );
    
        add_settings_section(
            'some_settings_section_id', // section ID
            '', // title (if needed)
            '', // callback function (if needed)
            'misha-slug' // page slug
        );
    
        add_settings_field(
            'homepage_text',
            'Test Title',
            'misha_text_field_html', // function which prints the field
            'misha-slug', // page slug
            'some_settings_section_id', // section ID
            array( 
                'label_for' => 'homepage_text',
                'class' => 'misha-class', // for <tr> element
            )
        );
    
    }
    
    function misha_text_field_html(){
        $setting = get_option('homepage_text');

?>
        <form method="post" action="">
            <input type="text" id="homepage_text" name="homepage_text" value="<?php echo isset( $setting ) ? esc_attr( $setting ) : ''; ?>">
        </form>
<?php
    }

    function change_tit(){
        $query = new WP_Query(array('s'=>'world'));
        $str = get_option('homepage_text');
        if ($query->have_posts()){
            while($query->have_posts()){
                $query->the_post();
                $id = get_the_id();
                $title = get_the_title();
                
                $newTitle = $str.' '.$title.' ';
                // echo "<br>".$newTitle;
                $link = strtolower(str_replace(' ', '-', $newTitle));
                // echo "<br>".$link;

                if(strpos($title, $str) === false) {
                    wp_update_post(array( 
                        'ID' => $id,
                        'post_title' => $newTitle,
                        'post_name'  => $link,
                    ));
                }
            }
        }else{
            echo 'khong co bai viet nao';
        }
    }
    add_action('init','change_tit');

